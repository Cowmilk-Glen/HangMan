"""
    Glenville Pecor
    Final Project - Hangman
    8/15/17
"""
import random

userWord = ''

WORDLIST =['ant', 'baboon', 'badger', 'bat', 'bear', 'beaver', 'camel', 'cat', 'clam', 'cobra', 'cougar', 'coyote', 'crow', 'deer', 'dog', \

            'donkey', 'duck', 'eagle', 'ferret', 'fox', 'frog', 'goat', 'goose', 'hawk', 'lion', 'lizard', 'llama', 'mole', 'monkey', 'moose', \

            'mouse', 'mule', 'newt', 'otter', 'owl', 'panda', 'parrot', 'pigeon', 'python', 'rabbit', 'ram', 'rat', 'raven', 'rhino', 'salmon', \

            'seal', 'shark', 'sheep', 'skunk', 'sloth', 'snake', 'spider', 'stork', 'swan', 'tiger', 'toad', 'trout', 'turkey', 'turtle', 'weasel',

            'whale', 'wolf', 'wombat', 'zebra']
newWL = WORDLIST[:] #copies the list to get a new list when the word runs out 



usedWords=[]



MAX_INCORRECT_GUESSES = 6  # max number of incorrect guesses before user loses



def display(badLetters, goodLetters, usersSolution):

    # Build the output of the incorrect guesses, and print it

    for usersSolution in userWord:
        print(usersSolution,end=' ')    




def getGuess(wrongLetters, rightLetters):

    # Returns the letter the player entered.



    print()

    a = input('Guess a letter: ')
    guess = a.lower() #makes unput lower case
    

    print()



    return guess

    



# Start of main program:
t = 1 #makes the loop run

while t==1:
    #wrote the code to check if there are no more words left in the list
    NWORDS = len(WORDLIST)
    if len(WORDLIST)==0:
        print("CONGRATS YOU RAN OUT OF WORDS")
        restart = input("Do you want to restart? If so type y, if not hit enter: ")
        restart = restart.lower()
        if restart == 'y':
            WORDLIST=newWL[:]
            NWORDS = len(WORDLIST)

        else:
            break
            
        
        
    #all the lsts and variables I had to make before
    usedWordsLst = []
    wrongLettersLst = []
    correctLettersLst = []
    guessLst = []
    x = 0
    y = 0
    z = 0
    turns = 5

    
    
    #welcome
    print('Welcome to H A N G M A N')


    
    wordIndex = random.randrange(0, NWORDS)

    secretWord = WORDLIST[wordIndex]  # choose a random word for this game
    length = len(secretWord)

        

##### For debugging during development.  Delete, or comment out to play for real ####

    # DELETE THIS FOR BUG CHECKING print("(secret word is: " + secretWord + ")")



    missedLetters = ''  # String of incorrect guesses

    correctLetters = ''  # String of correct guesses (ones that appear in the secretWord)



# Build up a string of all underscores (as many as are in the secret word)

    nLetters = len(secretWord)

    userWord = ''

    for index in range(nLetters):
    

        userWord = userWord + '_'    



# Loop for user's guesses

    while True:
        #checks if you won first
        if userWord == secretWord:
            correctLettersLst.append(guess)
            usedWordsLst.append(guess)
            print('\n\n\n')
            print("CONGRATS YOU WIN... STATS...")
            print("The letters you tried ",usedWordsLst)
            print("The wrong Letters you tried ", wrongLettersLst)
            print("The correct letters you tried ", correctLettersLst)
            question = input("Would you like to play again? If so type y: ")
            question = question.lower()
            if question == 'y':
                WORDLIST.remove(secretWord)
                break
            else:
                t=0
                break
        
    

        display(missedLetters, correctLetters, userWord)

    # Let the player type in a letter.

        guess = getGuess(missedLetters, correctLetters)
        """strippedUser = userWord.replace("_", "")
        LSU = len(strippedUser) + 1"""
        count = 0
        
       
       
        
        
   
        #first three are error checking
        if len(guess) != 1:
            print('Please enter a single letter.')
            
        elif guess not in 'abcdefghijklmnopqrstuvwxyz':
                print('Please enter a LETTER.')
        elif guess in correctLettersLst:
            print("PLESE ENTER IN SOMETHING YOU HAVE NOT PUT IN YET:")


           
            
        # See if the guess was a letter in the secret word   
        elif guess in secretWord:
            aze = 0
            
            for xz in secretWord:
               az=guess.count(xz)
               aze+=az
              
              
            if aze>1:
                #if there is more then one letter used in the word
                
                

                correctLetters = correctLetters + guess
                correctLettersLst.append(guess)
            
            
            
               
                      
            
                print('Yes, there is',aze,' of that letter: '+ guess )
                x+=1 #adds one ore to correct letters
                usedWordsLst.append(guess)
            
                print("The letters you tried ",usedWordsLst)
                        
                print("The wrong Letters you tried ", wrongLettersLst)
                print("The correct letters you tried ", correctLettersLst)
                x+=1
            else:
                #if there is only 1 of one letter in a word
                correctLetters = correctLetters + guess
                correctLettersLst.append(guess)
            
            
            
               
                      
                
                print('Yes, there is at least one: ' + guess )
                x+=1
                usedWordsLst.append(guess)
            
                print("The letters you tried ",usedWordsLst)
                        
                print("The wrong Letters you tried ", wrongLettersLst)
                print("The correct letters you tried ", correctLettersLst)
           
        



            # replace underscore(s) in userWord with user's guessed letter    

            for index in range(nLetters):
           

                if secretWord[index] == guess:
                    
                

                    userWord = userWord[ : index]  + guess + userWord[index +1 : ]
                    
                    
        #determins what to output        
        elif guess in wrongLettersLst:
            print("you already tired this wrong word please try again")
            print("The letters you tried ",usedWordsLst)
            print("The wrong Letters you tried ", wrongLettersLst)
            print("The correct letters you tried ", correctLettersLst)
        elif guess in correctLettersLst:
            print("you already tired this correct word please try again")
            print("The letters you tried ",usedWordsLst)
            print("The wrong Letters you tried ", wrongLettersLst)
            print("The correct letters you tried ", correctLettersLst)
        elif turns<1:
            print("GAME OVER")
            print('The word was',secretWord)
            print("The letters you tried ",usedWordsLst)
            print("The wrong Letters you tried ", wrongLettersLst)
            print("The correct letters you tried ", correctLettersLst)
            answer = input("Would you like to play again? If so type y: ")
            if answer == 'y':
                t = 1
                WORDLIST.remove(secretWord)
                
                break
            else:
                
                t = 0
                break

        


        
                


        

        else:  # Guess was not found in secret word

            missedLetters = missedLetters + guess

            print("No, there are no " + guess + "'s")
            turns-=1
            z+=1
            print("You have %i's turns left with %i wrong guesses"%((turns +1),(z)))
            usedWordsLst.append(guess)
            wrongLettersLst.append(guess)
            print("The letters you tried ",usedWordsLst)
            print("The wrong Letters you tried ", wrongLettersLst)
            print("The correct letters you tried ", correctLettersLst)
        print("Correct Letters(%i): " % (x))
            

    

print("GOOD BYE")

